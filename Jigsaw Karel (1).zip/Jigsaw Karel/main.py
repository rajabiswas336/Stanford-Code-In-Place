from karel.stanfordkarel import *

"""
Karel should finish the puzzle by picking up the last beeper 
(puzzle piece) and placing it in the right spot. Karel should 
end in the same position Karel starts in -- the bottom left 
corner of the world.
"""

def main():
    pick_up_beeper()
    place_beeper()
    return_home()

def pick_up_beeper():
    # Move to (1,3) and pick up beeper
    move()
    move()
    pick_beeper()

def place_beeper():
    # Move to (3,4) and place the beeper
    turn_left()
    move()
    turn_right()
    move()
    turn_left()
    move()
    put_beeper()

def return_home():
    # Return to (1,1) and face East
    turn_around()
    move()
    turn_left()
    move()
    move()
    turn_left()
    turn_left()
    move()
    move()
    move()
    move()
    move()
    turn_left()
    move()
    turn_left()
# Helper functions
def turn_right():
    for i in range(3):
        turn_left()

def turn_around():
    turn_left()
    turn_left()

# No need to edit below this
if __name__ == '__main__':
    main()
